# from .Data_Reading import read_file_auto_detect
# from .Data_Summary import data_summary
# from .Handling_Missing_Values import handle_missing_values
#from .Categorical_Data_Encoding import auto_one_hot_encode

from .DataKit import DataPrepKit


